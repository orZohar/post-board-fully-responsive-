export interface Post {
    authorName: string;
    content:string;
    date: Date;
}