import { ɵNullViewportScroller } from '@angular/common';
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, ContentChild, ContentChildren, Input, OnInit, SimpleChanges } from '@angular/core';
import { ContentPostCreatorComponent } from '../content-post-creator/content-post-creator.component';
import { NewPostComponent } from '../new-post/new-post.component';

@Component({
  selector: 'post',
  templateUrl: './post.component.html',
  styleUrls: ['./post.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class PostComponent implements OnInit {


  ngOnInit(): void {
 
  }

}